import { View, FlatList, StyleSheet } from 'react-native';
import CartaoProduto from '../components/CartaoProduto';

const produtos = [
  {
    id: '1',
    nome: 'Camiseta',
    descricao: 'Uma camiseta extra elegante',
    preco: 34.99,
    imagens: [require('../assets/imagens/camiseta1.png')],
  },
  {
    id: '2',
    nome: 'Calça Jeans',
    descricao: 'Uma calça jeans de classe',
    preco: 75.99,
    imagens: [require('../assets/imagens/calca-jeans1.png')],
  },
  {
    id: '3',
    nome: 'Calça Jeans',
    descricao: 'Uma calça jeans super confortável',
    preco: 88.99,
    imagens: [require('../assets/imagens/calca-jeans2.png')],
  },
];

const TelaListaProdutos = () => (
  <View style={styles.container}>
    <FlatList
      data={produtos}
      renderItem={({ item }) => (
        <CartaoProduto
          nome={item.nome}
          descricao={item.descricao}
          preco={item.preco}
          imagem={item.imagens[0]} 
        />
      )}
      keyExtractor={item => item.id}
      contentContainerStyle={styles.listaProdutos}
    />
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  listaProdutos: {
    paddingVertical: 20,
    paddingHorizontal: 10,
  },
});

export default TelaListaProdutos;