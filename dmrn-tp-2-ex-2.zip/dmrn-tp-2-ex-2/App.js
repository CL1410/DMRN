import { View } from 'react-native';
import TelaListaProdutos from './screens/TelaListaProdutos'; // 

const App = () => {
  return (
    <View style={{ flex: 1 }}>
      <TelaListaProdutos />
    </View>
  );
};

export default App;