import { View, Text, Image, StyleSheet } from 'react-native';


const CartaoProduto = ({ nome, descricao, preco, imagem }) => (
  <View style={styles.container}>
    <Image source={imagem} style={styles.imagem} />
    <View style={styles.infoContainer}>
      <Text style={styles.nome}>{nome}</Text>
      <Text style={styles.descricao}>{descricao}</Text>
      <Text style={styles.preco}>R${preco.toFixed(2)}</Text>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#f9f5f9',
    borderRadius: 10,
    marginBottom: 30,
    overflow: 'hidden',
  },
  imagem: {
    width: 100,
    height: 100,
    resizeMode: 'cover',
  },
  infoContainer: {
    flex: 1,
    padding: 10,
  },
  nome: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  descricao: {
    fontSize: 16,
    marginBottom: 5,
  },
  preco: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#071bff', 
  },
});

export default CartaoProduto;